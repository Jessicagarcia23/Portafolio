class RentbikeController < ApplicationController
    
    def signup 
        
    end

end